# Waste-sorting-using-barcode-scanning ```Java```
---
바코드 스캔을 이용한 분리수거 어플리케이션

프로젝트 기간 : 2020.10 ~

사용 오픈소스 : zxing-android-embedded:4.1.0
